import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

root=Path('/tmp/loam-1963-formal')
repo=root/'product435'
lake=root/'elan/toolchains/leanprover--lean4---v4.35.0/bin/lake'
records=[]

def run(label,cwd,args,budget=300):
    start=time.monotonic()
    log_path=root/f'formal-{label}.log'
    with log_path.open('w') as log:
        p=subprocess.Popen(['/usr/bin/time','-l',str(lake),*args],cwd=cwd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try: code=p.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL);p.wait();code=124
    text=log_path.read_text()
    rss=re.search(r'(\d+)\s+maximum resident set size',text)
    row=dict(label=label,command=[str(lake),*args],exit=code,wall_s=round(time.monotonic()-start,3),max_rss_bytes=int(rss[1]) if rss else None)
    records.append(row)
    (root/'local-fixture-results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    return code

for n in [165,166,167,168,238]:
    dst=root/f'formal-observation{n}';dst.mkdir()
    for name in ['Challenge.lean','Solution.lean','config.json']:
        shutil.copyfile(repo/'verification'/f'observation{n}'/name,dst/name)
    (dst/'lakefile.toml').write_text(f'name = "specimen{n}"\n[[lean_lib]]\nname = "Challenge"\n[[lean_lib]]\nname = "Solution"\n')
    if n==168:
        cfg=json.loads((dst/'config.json').read_text());del cfg['enable_nanoda']
        cfg['external_kernels']={'nanoda':[str(lake.parent/'nanoda_bin')]}
        (dst/'config.json').write_text(json.dumps(cfg,indent=2)+'\n')
    run(f'{n}-build',dst,['build','Challenge','Solution'])
    for rep in range(3):run(f'{n}-comparator-{rep}',dst,['comparator','--config','config.json','--inadvisably-no-sandbox'])
    if n in [165,166,167,168]:run(f'{n}-paranoid',dst,['comparator','--config','config.json','--paranoid','--inadvisably-no-sandbox'],180)

scope=root/'formal-scope';scope.mkdir()
(scope/'lakefile.toml').write_text('name = "scopeprobe"\ndefaultTargets = ["Product"]\n[[lean_lib]]\nname = "Product"\n[[lean_lib]]\nname = "Durable"\n[[lean_lib]]\nname = "Dormant"\n')
(scope/'Product.lean').write_text('namespace ScopeProbe\ntheorem product_claim : 1 = 1 := rfl\nend ScopeProbe\n')
(scope/'Durable.lean').write_text('namespace ScopeProbe\naxiom forbidden_fact : False\ntheorem durable_claim : False := forbidden_fact\nend ScopeProbe\n')
(scope/'Dormant.lean').write_text('namespace ScopeProbe\naxiom unused_fact : False\nend ScopeProbe\n')
run('scope-build',scope,['build','Product','Durable','Dormant'])
run('scope-no-Linux-sandbox',scope,['check'])
# Targeted artifacts first; full-environment costs are separate bounded observations.
for module,target in [('Product','ScopeProbe.product_claim'),('Durable','ScopeProbe.durable_claim'),('Dormant','ScopeProbe.unused_fact')]:
    export=scope/f'{module}.ndjson'
    with export.open('w') as f:
        p=subprocess.run([lake,'env','leanexport',module,'--',target],cwd=scope,stdout=f,stderr=subprocess.PIPE,text=True)
    assert p.returncode==0,p.stderr
    run(f'{module}-export-check',scope,['check','--from-export',str(export),'--inadvisably-no-sandbox'])
    if module=='Product':run('Product-export-paranoid',scope,['check','--from-export',str(export),'--paranoid','--inadvisably-no-sandbox'],180)
run('scope-check',scope,['check','--inadvisably-no-sandbox'])
run('scope-check-paranoid',scope,['check','--paranoid','--inadvisably-no-sandbox'],180)
print('DONE',flush=True)

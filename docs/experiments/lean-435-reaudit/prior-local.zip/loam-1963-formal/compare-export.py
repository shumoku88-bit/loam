import json
from pathlib import Path
root=Path('/tmp/loam-1963-formal')
inventory=[json.loads(l) for l in (root/'formal-inventory.jsonl').read_text().splitlines() if l.startswith('{')][1]
names={0:''}
exported=set()
counts={}
with (root/'actual-durable.ndjson').open() as f:
    for line in f:
        item=json.loads(line)
        if 'in' in item:
            if 'str' in item:
                value=item['str'];piece=value['str']
            elif 'num' in item:
                value=item['num'];piece=str(value['i'])
            else:
                raise AssertionError(item)
            prefix=names[value['pre']]
            names[item['in']]=f'{prefix}.{piece}' if prefix else piece
        for kind in ['axiom','def','thm','opaque','quot']:
            if kind in item:
                exported.add(names[item[kind]['name']])
                counts[kind]=counts.get(kind,0)+1
        if 'inductive' in item:
            for kind in ['types','ctors','recs']:
                for value in item['inductive'][kind]:
                    exported.add(names[value['name']])
                    counts[kind]=counts.get(kind,0)+1
expected=set(inventory['declarationNames'])
report=dict(root=inventory['root'],candidate_count=len(expected),exported_candidates=len(expected & exported),
            missing=sorted(expected-exported),total_exported_declarations=len(exported),
            exported_kind_counts=counts,internal_candidates=inventory['internalNames'],unsafe_candidates=inventory['unsafeNames'])
(root/'export-coverage.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
# A proof environment export must contain the root's named correspondence theorems.
assert any('hashIndexBy_get?_eq_findBy?' in name for name in exported)
assert any('buildEventIndex_get?_eq_findById?' in name for name in exported)
assert not any('buildCoverageIndex_getD_eq_currentCoverageFor' in name for name in exported)
assert expected-exported <= set(inventory['internalNames'])
assert len(expected)==1150 and len(expected & exported)==997

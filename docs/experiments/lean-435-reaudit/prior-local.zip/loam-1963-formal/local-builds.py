import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path('/tmp/loam-1963-formal')
records = []
for version, directory, binary in [
    ('4.33.1', 'product433', Path('/Users/user/.elan/toolchains/leanprover--lean4---v4.33.1/bin/lake')),
    ('4.35.0', 'product435', root/'elan/toolchains/leanprover--lean4---v4.35.0/bin/lake'),
]:
    cwd = root/directory
    commands = [
        ('product-cold', ['build', 'Loam']),
        ('durable-incremental', ['build', 'Loam.DurableProofs']),
        ('product-warm', ['build', 'Loam']),
        ('durable-warm', ['build', 'Loam.DurableProofs']),
        ('durable-checker', ['env', 'leanchecker', '--silent', 'Loam.DurableProofs']),
        ('pta-test', ['env', 'lean', '--run', 'Loam/Tests/PtaMigrationClassifier.lean']),
        ('discharge-test', ['env', 'lean', '--run', 'Loam/Tests/RelationDischargeFrontier.lean']),
        ('coverage-test', ['env', 'lean', '--run', 'Loam/Tests/CurrentCoverageInspection.lean']),
    ]
    for label, args in commands:
        log_path = root/f'{version}-{label}.log'
        start = time.monotonic()
        env = dict(os.environ, PATH=f'{binary.parent}:{os.environ["PATH"]}')
        with log_path.open('w') as log:
            p = subprocess.Popen(['/usr/bin/time', '-l', str(binary), *args], cwd=cwd, env=env,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = p.wait(timeout=600)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                p.wait()
                code = 124
        row = dict(version=version, label=label, command=[str(binary), *args], exit=code,
                   wall_s=round(time.monotonic()-start, 3))
        records.append(row)
        (root/'local-build-results.json').write_text(json.dumps(records, indent=2)+'\n')
        print(json.dumps(row), flush=True)
        if label == 'product-cold' and code != 0:
            print('Product failed: still inspect independent durable target; skip dependent tests if needed.', flush=True)
print('DONE', flush=True)

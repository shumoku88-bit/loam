namespace ScopeProbe
axiom unused_fact : False
end ScopeProbe

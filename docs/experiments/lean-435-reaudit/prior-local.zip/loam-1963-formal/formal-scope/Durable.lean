namespace ScopeProbe
axiom forbidden_fact : False
theorem durable_claim : False := forbidden_fact
end ScopeProbe

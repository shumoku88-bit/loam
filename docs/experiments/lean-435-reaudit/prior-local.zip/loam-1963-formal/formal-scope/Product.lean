namespace ScopeProbe
theorem product_claim : 1 = 1 := rfl
end ScopeProbe

#!/usr/bin/env python3
"""One-shot issue-1963 measurement; temporary branch only, not a CI gate."""
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

repo = Path.cwd()
out = Path(os.environ['RUNNER_TEMP'])/'lean435-results'
work = Path(os.environ['RUNNER_TEMP'])/'lean435-work'
out.mkdir(exist_ok=True)
work.mkdir(exist_ok=True)
records = []

def run(label, cwd, args, budget=300):
    start = time.monotonic()
    with (out/f'{label}.log').open('w') as log:
        child = subprocess.Popen(['/usr/bin/time', '-v', *map(str, args)], cwd=cwd,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = child.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait()
            code = 124
    text = (out/f'{label}.log').read_text(errors='replace')
    rss = re.search(r'Maximum resident set size \(kbytes\): (\d+)', text)
    row = dict(label=label, command=list(map(str,args)), exit=code,
               wall_s=round(time.monotonic()-start,3),
               max_rss_kib=int(rss[1]) if rss else None)
    records.append(row)
    (out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if code:
        print(text[-2000:],flush=True)
    return code

inventory = work/'Inventory.lean'
inventory.write_text('''import Lean
open Lean

def main : IO Unit := do
  initSearchPath (← findSysroot)
  for root in #[`Loam, `Loam.DurableProofs] do
    let env ← importModules #[{ module := root }] {} (trustLevel := 1024)
    let mods := env.allImportedModuleNames
    let ownMods := mods.filter ((`Loam).isPrefixOf ·)
    let decls : Array (Name × ConstantInfo) := env.constants.fold (init := #[]) fun acc name info =>
      match env.getModuleIdxFor? name with
      | some idx => if (`Loam).isPrefixOf mods[idx.toNat]! then acc.push (name, info) else acc
      | none => acc
    let thms := decls.filter fun (_, info) => match info with | .thmInfo _ => true | _ => false
    IO.println <| Json.compress <| Json.mkObj [
      ("root", toJson root.toString), ("modules", toJson (ownMods.map Name.toString)),
      ("declarationNames", toJson (decls.map fun (n, _) => n.toString)),
      ("declarations", toJson decls.size), ("theorems", toJson thms.size)]
''')

bins = {v: Path(os.environ['ELAN_HOME'])/'toolchains'/f'leanprover--lean4---v{v}'/'bin' for v in ['4.33.1','4.35.0']}
# Immutable source copies; no repository .lake cache is reused or saved.
for v in bins:
    dst = work/f'product-{v}'
    dst.mkdir()
    for name in ['Loam','tests','tools','Loam.lean','lakefile.lean','lake-manifest.json','lean-toolchain']:
        src=repo/name
        if src.is_dir(): shutil.copytree(src,dst/name)
        else: shutil.copyfile(src,dst/name)
    lake=bins[v]/'lake'
    product=run(f'{v}-product-cold',dst,[lake,'build','Loam'],600)
    durable=run(f'{v}-durable-incremental',dst,[lake,'build','Loam.DurableProofs'],600)
    run(f'{v}-product-warm',dst,[lake,'build','Loam'],600)
    run(f'{v}-durable-warm',dst,[lake,'build','Loam.DurableProofs'],600)
    if durable == 0:
        run(f'{v}-durable-checker',dst,[lake,'env','leanchecker','--silent','Loam.DurableProofs'])
    if product == 0:
        for name in ['PtaMigrationClassifier','RelationDischargeFrontier','CurrentCoverageInspection']:
            run(f'{v}-test-{name}',dst,[lake,'env','lean','--run',f'Loam/Tests/{name}.lean'])
    if product == 0 and durable == 0:
        run(f'{v}-inventory',dst,[lake,'env','lean','--run',inventory])
    # Exact production audit executable, independently compiled per version.
    audit=work/f'audit-{v}'
    run(f'{v}-audit-clone',work,['git','clone','--depth','1','--branch','v0.1.2','https://github.com/leanprover-community/axiom-audit.git',audit])
    sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=audit,text=True).strip()
    assert sha == '46024e005996495c65ef609368e11ab39c4222e3',sha
    run(f'{v}-audit-build',audit,[lake,'build'])
    if durable == 0:
        run(f'{v}-durable-audit',dst,[lake,'env',audit/'.lake/build/bin/axiom-audit','--root','Loam','--modules','Loam.DurableProofs','--allow','propext,Classical.choice,Quot.sound'])

lake=bins['4.35.0']/'lake'
# Standard bubblewrap only; no shim, sudo checker, host sysctl change or sandbox bypass.
smoke=run('bwrap-smoke',work,['bwrap','--unshare-all','--ro-bind','/','/','--','true'],30)
if smoke != 0:
    print('Distro bubblewrap unavailable: record environment failure without bypass.',flush=True)

specimens={}
for n in [165,166,167,168,238]:
    dst=work/f'observation{n}'
    dst.mkdir()
    for name in ['Challenge.lean','Solution.lean','config.json']:
        shutil.copyfile(repo/'verification'/f'observation{n}'/name,dst/name)
    (dst/'lakefile.toml').write_text(f'name = "specimen{n}"\n[[lean_lib]]\nname = "Challenge"\n[[lean_lib]]\nname = "Solution"\n')
    # Explicit native Lake paths select the release without changing repository pins.
    if n == 168:
        cfg=json.loads((dst/'config.json').read_text())
        del cfg['enable_nanoda']
        cfg['external_kernels']={'nanoda':[str(bins['4.35.0']/'nanoda_bin')]}
        (dst/'config.json').write_text(json.dumps(cfg,indent=2)+'\n')
    run(f'{n}-build',dst,[lake,'build','Challenge','Solution'])
    for rep in range(3):
        run(f'{n}-comparator-{rep}',dst,[lake,'comparator','--config','config.json'])
    specimens[n]=dst
# Normal and strict negative cases also tested with all bundled checkers.
for n in [165,166,167,168]:
    run(f'{n}-paranoid',specimens[n],[lake,'comparator','--config','config.json','--paranoid'],180)

scope=work/'scope'
scope.mkdir()
(scope/'lakefile.toml').write_text('name = "scopeprobe"\ndefaultTargets = ["Product"]\n[[lean_lib]]\nname = "Product"\n[[lean_lib]]\nname = "Durable"\n[[lean_lib]]\nname = "Dormant"\n')
(scope/'Product.lean').write_text('namespace ScopeProbe\ntheorem product_claim : 1 = 1 := rfl\nend ScopeProbe\n')
(scope/'Durable.lean').write_text('namespace ScopeProbe\naxiom forbidden_fact : False\ntheorem durable_claim : False := forbidden_fact\nend ScopeProbe\n')
(scope/'Dormant.lean').write_text('namespace ScopeProbe\naxiom unused_fact : False\nend ScopeProbe\n')
run('scope-build',scope,[lake,'build','Product','Durable','Dormant'])
run('scope-check',scope,[lake,'check'])
run('scope-check-paranoid',scope,[lake,'check','--paranoid'],180)
for module,target in [('Durable','ScopeProbe.durable_claim'),('Dormant','ScopeProbe.unused_fact'),('Product','ScopeProbe.product_claim')]:
    export=scope/f'{module}.ndjson'
    with export.open('w') as f:
        p=subprocess.run([lake,'env','leanexport',module,'--',target],cwd=scope,stdout=f,stderr=subprocess.PIPE,text=True)
    assert p.returncode == 0,p.stderr
    run(f'{module}-export-check',scope,[lake,'check','--from-export',export])
    if module == 'Product':
        run('Product-export-paranoid',scope,[lake,'check','--from-export',export,'--paranoid'],180)
# Exact compiled audit rejects the dormant declaration, for both version policies.
for v in bins:
    base=work/f'dormant-{v}'
    base.mkdir()
    (base/'lakefile.toml').write_text('name = "dormant"\n[[lean_lib]]\nname = "Dormant"\n')
    shutil.copyfile(scope/'Dormant.lean',base/'Dormant.lean')
    run(f'{v}-dormant-build',base,[bins[v]/'lake','build','Dormant'])
    run(f'{v}-dormant-audit',base,[bins[v]/'lake','env',work/f'audit-{v}'/'.lake/build/bin/axiom-audit','--root','Dormant','--modules','Dormant','--allow','propext,Classical.choice,Quot.sound','--json'])

# Real durable environment export: inventory and normal check, bounded independently.
dst=work/'product-4.35.0'
if next(r for r in records if r['label']=='4.35.0-durable-incremental')['exit']==0:
    export=work/'actual-durable.ndjson'
    start=time.monotonic()
    with export.open('w') as f:
        p=subprocess.run([lake,'env','leanexport','Loam.DurableProofs'],cwd=dst,stdout=f,stderr=subprocess.PIPE,text=True)
    (out/'durable-export-metadata.json').write_text(json.dumps(dict(exit=p.returncode,wall_s=round(time.monotonic()-start,3),bytes=export.stat().st_size,sha256=hashlib.sha256(export.read_bytes()).hexdigest()),indent=2)+'\n')
    if p.returncode==0:
        run('actual-durable-export-check',dst,[lake,'check','--from-export',export],300)

# Synthetic markers, not user secrets; the actual build must establish each assertion.
home=Path.home()/'loam1963-home-marker'
tmp=Path('/tmp/loam1963-host-marker')
public=Path('/opt/loam1963-public-marker')
home.write_text('synthetic private home marker')
tmp.write_text('synthetic private tmp marker')
subprocess.run(['sudo','sh','-c',f'printf public-synthetic > {public}; chmod 666 {public}'],check=True)
os.environ['LOAM_1963_NOT_SECRET']='synthetic-host-env'
probe=work/'sandbox-probe'
shutil.copytree(specimens[165],probe,ignore=shutil.ignore_patterns('.lake'))
code=f'''import errno, os, socket
from pathlib import Path
assert not Path({str(home)!r}).exists(), 'home exposed'
assert not Path({str(tmp)!r}).exists(), 'host tmp exposed'
assert os.getenv('LOAM_1963_NOT_SECRET') is None, 'host env exposed'
assert Path({str(public)!r}).read_text() == 'public-synthetic', 'expected public root visibility'
for p in [Path({str(public)!r}),Path({str(probe/'source-write')!r})]:
 try:
  p.write_text('unexpected write')
 except OSError as e:
  assert e.errno == errno.EROFS, (str(p),e)
 else:
  raise AssertionError('read-only mount writable')
Path({str(probe/'.lake/sandbox-write')!r}).write_text('allowed')
interfaces=[l.split(':')[0].strip() for l in Path('/proc/net/dev').read_text().splitlines() if ':' in l]
assert interfaces == ['lo'], interfaces
s=socket.socket(); s.settimeout(3)
status=s.connect_ex(('1.1.1.1',443)); s.close()
assert status != 0, 'external network reachable'
print('SANDBOX_ASSERTIONS_PASSED: home/tmp/env masked; root/source read-only; .lake writable; loopback only; public root readable; connect errno='+str(status))
'''
with (probe/'Solution.lean').open('a') as f:
    f.write('\n#eval do\n  let out ← IO.Process.output { cmd := "/usr/bin/python3", args := #['+json.dumps(code)+'] }\n  IO.println out.stdout\n  if out.exitCode != 0 then throw (IO.userError out.stderr)\n')
run('sandbox-build-assertions',probe,[lake,'comparator','--config','config.json'])
if (probe/'.lake/sandbox-write').exists():
    assert (probe/'.lake/sandbox-write').read_text()=='allowed'
    (out/'sandbox-host-check.txt').write_text('Writable .lake marker observed on host; synthetic home/tmp/public markers remain intact.\n')
assert home.read_text()=='synthetic private home marker'
assert tmp.read_text()=='synthetic private tmp marker'
assert public.read_text()=='public-synthetic'
print('DONE: raw logs and results retained for review; expected rejection is not workflow failure.',flush=True)

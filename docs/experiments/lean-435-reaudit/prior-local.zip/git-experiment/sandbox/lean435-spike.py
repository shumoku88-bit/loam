#!/usr/bin/env python3
"""Final, marker-only replay: standard Lake/bubblewrap; temporary branch only."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

repo=Path.cwd()
out=Path(os.environ['RUNNER_TEMP'])/'lean435-results'
probe=Path(os.environ['RUNNER_TEMP'])/'lean435-sandbox-probe'
out.mkdir(exist_ok=True)
probe.mkdir()
lake=Path(os.environ['ELAN_HOME'])/'toolchains/leanprover--lean4---v4.35.0/bin/lake'
records=[]

def run(label,args):
    start=time.monotonic()
    with (out/f'{label}.log').open('w') as log:
        p=subprocess.run(['/usr/bin/time','-v',*map(str,args)],cwd=probe,stdout=log,stderr=subprocess.STDOUT,timeout=60)
    records.append(dict(label=label,command=list(map(str,args)),exit=p.returncode,wall_s=round(time.monotonic()-start,3)))
    (out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records[-1]),flush=True)
    return p.returncode

assert run('bwrap-smoke',['bwrap','--unshare-all','--ro-bind','/','/','--','true'])==0
for name in ['Challenge.lean','Solution.lean','config.json']:
    shutil.copyfile(repo/'verification/observation165'/name,probe/name)
(probe/'lakefile.toml').write_text('name = "sandboxprobe"\n[[lean_lib]]\nname = "Challenge"\n[[lean_lib]]\nname = "Solution"\n')
# Only trusted TOML is loaded here; neither Lean module is built on the host.
assert run('manifest-only',[lake,'env'])==0
assert (probe/'lake-manifest.json').exists()
home=Path.home()/'loam1963-home-marker'
tmp=Path('/tmp/loam1963-host-marker')
public=Path('/opt/loam1963-public-marker')
home.write_text('synthetic private home marker')
tmp.write_text('synthetic private tmp marker')
subprocess.run(['sudo','sh','-c',f'printf public-synthetic > {public}; chmod 666 {public}'],check=True)
os.environ['LOAM_1963_NOT_SECRET']='synthetic-host-env'
code=f'''import errno, os, socket
from pathlib import Path
assert not Path({str(home)!r}).exists(), 'home exposed'
assert not Path({str(tmp)!r}).exists(), 'host tmp exposed'
assert os.getenv('LOAM_1963_NOT_SECRET') is None, 'host env exposed'
assert Path({str(public)!r}).read_text() == 'public-synthetic', 'expected public root visibility'
for p in [Path({str(public)!r}),Path({str(probe/'source-write')!r})]:
 try:
  p.write_text('unexpected write')
 except OSError as e:
  assert e.errno == errno.EROFS, (str(p),e)
 else:
  raise AssertionError('read-only mount writable')
Path({str(probe/'.lake/sandbox-write')!r}).write_text('allowed')
interfaces=[l.split(':')[0].strip() for l in Path('/proc/net/dev').read_text().splitlines() if ':' in l]
assert interfaces == ['lo'], interfaces
s=socket.socket(); s.settimeout(3)
status=s.connect_ex(('1.1.1.1',443)); s.close()
assert status != 0, 'external network reachable'
print('SANDBOX_ASSERTIONS_PASSED: home/tmp/env masked; root/source read-only; .lake writable; loopback only; public root readable; connect errno='+str(status))
'''
with (probe/'Solution.lean').open('a') as f:
    f.write('\n#eval do\n  let out ← IO.Process.output { cmd := "/usr/bin/python3", args := #["-c", '+json.dumps(code)+'] }\n  IO.println out.stdout\n  if out.exitCode != 0 then throw (IO.userError out.stderr)\n')
assert run('sandbox-build-assertions',[lake,'comparator','--config','config.json'])==0
assert 'SANDBOX_ASSERTIONS_PASSED' in (out/'sandbox-build-assertions.log').read_text()
assert (probe/'.lake/sandbox-write').read_text()=='allowed'
assert home.read_text()=='synthetic private home marker'
assert tmp.read_text()=='synthetic private tmp marker'
assert public.read_text()=='public-synthetic'
(out/'sandbox-host-check.txt').write_text('Host verified .lake write; synthetic home/tmp/public markers intact. No sandbox bypass, wrapper, sudo Lake, or host policy change.\n')
print('ALL_MARKER_ASSERTIONS_PASSED',flush=True)

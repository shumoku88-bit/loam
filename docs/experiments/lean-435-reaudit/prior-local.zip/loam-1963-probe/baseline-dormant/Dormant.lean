namespace ScopeProbe
axiom unused_fact : False
end ScopeProbe
#print axioms ScopeProbe.unused_fact

#!/usr/bin/env python3
"""Trusted, unsandboxed rc3 preview only; never formal v4.35 or Linux evidence."""
import json
import os
import signal
from pathlib import Path
import re
import shutil
import subprocess
import time

REPO = Path('/Users/user/Projects/moko/loam')
ROOT = Path(__file__).resolve().parent
LAKE = ['lake', '+leanprover/lean4:v4.35.0-rc3']
records = json.loads((ROOT / 'results.json').read_text())

def run(label, cwd, args, expected):
    previous = next((r for r in records if r['label'] == label), None)
    if previous is not None:
        assert previous['exit'] == expected
        return (ROOT / f'{label}.log').read_text()
    start = time.monotonic()
    log_path = ROOT / f'{label}.log'
    with log_path.open('w') as log:
        p = subprocess.Popen(['/usr/bin/time', '-l', *args], cwd=cwd,
                             stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = p.wait(timeout=180)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGKILL)
            p.wait()
            code = 124
    elapsed = time.monotonic() - start
    output = log_path.read_text()
    rss = re.search(r'(\d+)\s+maximum resident set size', output)
    record = dict(label=label, cwd=str(cwd), command=args, exit=code,
                  wall_s=round(elapsed, 3), max_rss_bytes=int(rss[1]) if rss else None)
    records.append(record)
    (ROOT / 'results.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    assert code in (expected if isinstance(expected, tuple) else (expected,)), (label, expected, code, output[-4000:])
    return output

# Resume after the discovered strict-empty-allowlist Nanoda integration failure.
assert 'nanoda exited with 101' in (ROOT / '165-paranoid.log').read_text()
for num, expected in [(168, 0), (238, 0)]:
    cwd = ROOT / f'observation{num}'
    cwd.mkdir(exist_ok=True)
    for name in ['Challenge.lean', 'Solution.lean', 'config.json']:
        shutil.copyfile(REPO / 'verification' / f'observation{num}' / name, cwd / name)
    (cwd / 'lean-toolchain').write_text('leanprover/lean4:v4.35.0-rc3\n')
    (cwd / 'lakefile.toml').write_text(f'name = "probe{num}"\n[[lean_lib]]\nname = "Challenge"\n[[lean_lib]]\nname = "Solution"\n')
    if num == 168:
        config = json.loads((cwd / 'config.json').read_text())
        del config['enable_nanoda']
        config['external_kernels'] = {'nanoda': ['/Users/user/.elan/toolchains/leanprover--lean4---v4.35.0-rc3/bin/nanoda_bin']}
        (cwd / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
    run(f'{num}-build-cold', cwd, LAKE + ['build', 'Challenge', 'Solution'], 0)
    run(f'{num}-sandbox-required', cwd, LAKE + ['comparator', '--config', 'config.json'], 2)
    for n in range(3):
        output = run(f'{num}-comparator-warm-{n}', cwd, LAKE + ['comparator', '--config', 'config.json', '--inadvisably-no-sandbox'], expected)
        if num == 166:
            assert 'Your solution is okay!' not in output
        if num == 167:
            assert 'unpermitted_fact' in output
    if num == 168:
        run(f'{num}-paranoid', cwd, LAKE + ['comparator', '--config', 'config.json', '--paranoid', '--inadvisably-no-sandbox'], 0)

cwd = ROOT / 'scope'
cwd.mkdir(exist_ok=True)
(cwd / 'lean-toolchain').write_text('leanprover/lean4:v4.35.0-rc3\n')
(cwd / 'lakefile.toml').write_text('name = "scopeprobe"\ndefaultTargets = ["Product"]\n[[lean_lib]]\nname = "Product"\n[[lean_lib]]\nname = "Durable"\n')
(cwd / 'Product.lean').write_text('namespace ScopeProbe\ntheorem product_claim : 1 = 1 := rfl\nend ScopeProbe\n')
(cwd / 'Durable.lean').write_text('namespace ScopeProbe\naxiom forbidden_fact : False\ntheorem durable_claim : False := forbidden_fact\nend ScopeProbe\n')
run('scope-build-all', cwd, LAKE + ['build', 'Product', 'Durable'], 0)
run('scope-sandbox-required', cwd, LAKE + ['check'], 2)
for n in range(3):
    run(f'scope-check-warm-{n}', cwd, LAKE + ['check', '--inadvisably-no-sandbox'], 0)
run('scope-check-paranoid', cwd, LAKE + ['check', '--paranoid', '--inadvisably-no-sandbox'], (0, 124))
export = subprocess.run(LAKE + ['env', 'leanexport', 'Durable', '--', 'ScopeProbe.durable_claim'], cwd=cwd, capture_output=True, text=True)
assert export.returncode == 0, export.stderr
(cwd / 'durable.ndjson').write_text(export.stdout)
output = run('scope-durable-export-rejected', cwd, LAKE + ['check', '--from-export', 'durable.ndjson', '--inadvisably-no-sandbox'], 1)
assert 'forbidden_fact' in output
print('All expected exit codes and focused negative assertions passed.')

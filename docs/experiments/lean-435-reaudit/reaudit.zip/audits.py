"""Replay unchanged pinned compiled axiom-audit with both toolchains."""
import json, os, subprocess, time
from pathlib import Path
root=Path('/tmp/loam-1963-reaudit')
bins={'a':Path('/Users/user/.elan/toolchains/leanprover--lean4---v4.33.1/bin'),
'b':Path('/tmp/loam-1963-formal/elan/toolchains/leanprover--lean4---v4.35.0/bin')}
rows=[]
for k,bin in bins.items():
    audit=root/('audit-'+k)
    sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=audit,text=True).strip()
    assert sha=='46024e005996495c65ef609368e11ab39c4222e3'
    tasks=[('setup',audit,['build'],0)]
    for rep in range(3):
        tasks.append((f'durable-{rep}',root/k,['env',audit/'.lake/build/bin/axiom-audit','--root','Loam','--modules','Loam.DurableProofs','--allow','propext,Classical.choice,Quot.sound','--json'],0))
    for name,source in [('Dormant','axiom unused_fact : False\n'),
                        ('Used','axiom bad : False\ntheorem claim : False := bad\n'),
                        ('Native','theorem claim : 1 = 1 := by native_decide\n')]:
        d=root/(name+'-'+k);d.mkdir()
        (d/'lakefile.toml').write_text(f'name = "probe"\n[[lean_lib]]\nname = "{name}"\n')
        (d/(name+'.lean')).write_text(source)
        tasks.extend([(name+'-build',d,['build',name],0),
                      (name+'-audit',d,['env',audit/'.lake/build/bin/axiom-audit','--root',name,'--modules',name,'--json'],1)])
    for label,cwd,args,expected in tasks:
        cmd=[str(bin/'lake'),*map(str,args)];start=time.monotonic()
        with (root/f'audit-{k}-{label}.log').open('w') as log:
            p=subprocess.run(['/usr/bin/time','-l',*cmd],cwd=cwd,
                env=dict(os.environ,PATH=str(bin)+':'+os.environ['PATH']),stdout=log,stderr=subprocess.STDOUT,timeout=120)
        row=dict(label=f'audit-{k}-{label}',cwd=str(cwd),command=cmd,exit=p.returncode,expected=expected,wall_s=round(time.monotonic()-start,3))
        rows.append(row);(root/'audit-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
        assert p.returncode==expected

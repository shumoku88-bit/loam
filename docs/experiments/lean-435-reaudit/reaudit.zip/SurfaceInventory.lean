import Lean
open Lean

def main : IO Unit := do
  initSearchPath (← findSysroot)
  for root in #[`Loam, `Loam.DurableProofs] do
    let env ← importModules #[{ module := root }] {} (trustLevel := 1024)
    let mods := env.allImportedModuleNames
    let ownMods := mods.filter ((`Loam).isPrefixOf ·)
    let decls : Array (Name × ConstantInfo) := env.constants.fold (init := #[]) fun acc name info =>
      match env.getModuleIdxFor? name with
      | some idx => if (`Loam).isPrefixOf mods[idx.toNat]! then acc.push (name, info) else acc
      | none => acc
    let thms := decls.filter fun (_, info) => match info with | .thmInfo _ => true | _ => false
    IO.println <| Json.compress <| Json.mkObj [
      ("root", toJson root.toString),
      ("modules", toJson (ownMods.map Name.toString)),
      ("declarations", toJson decls.size),
      ("theorems", toJson thms.size),
      ("declarationNames", toJson (decls.map fun (n, _) => n.toString)),
      ("theoremNames", toJson (thms.map fun (n, _) => n.toString)),
      ("internalNames", toJson (decls.filter (fun (n, _) => n.isInternal) |>.map fun (n, _) => n.toString)),
      ("unsafeNames", toJson (decls.filter (fun (_, i) => i.isUnsafe) |>.map fun (n, _) => n.toString)),
      ("totalImportedDeclarations", toJson (env.constants.fold (init := 0) fun n _ _ => n + 1))]

import Lean
open Lean

def kind : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "def"
  | .thmInfo _ => "thm"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quot"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "ctor"
  | .recInfo _ => "rec"

def main : IO Unit := do
  initSearchPath (← findSysroot)
  let env ← importModules #[{ module := `Loam.DurableProofs }] {} (trustLevel := 1024)
  let mods := env.allImportedModuleNames
  IO.println <| Json.compress <| Json.mkObj [("modules", toJson (mods.filter ((`Loam).isPrefixOf ·) |>.map Name.toString))]
  for (n, i) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? n then
      if (`Loam).isPrefixOf mods[idx.toNat]! then
        let refs := (i.type.getUsedConstants ++ (i.value?.getD (.sort .zero)).getUsedConstants).toList
        IO.println <| Json.compress <| Json.mkObj [
          ("name", toJson n.toString), ("module", toJson mods[idx.toNat]!.toString),
          ("kind", toJson (kind i)), ("internal", toJson n.isInternal),
          ("unsafe", toJson i.isUnsafe), ("partial", toJson i.isPartial),
          ("refs", toJson (refs.map Name.toString))]

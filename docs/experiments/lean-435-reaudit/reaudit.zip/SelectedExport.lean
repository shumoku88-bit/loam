import LeanExport.Basic
open Lean

-- One-shot scope adapter: use the audit's module ownership, not name visibility.
def main : IO Unit := do
  initSearchPath (← findSysroot)
  let env ← importModules #[{ module := `Loam.DurableProofs }] {}
  let mods := env.allImportedModuleNames
  let names := env.constants.toList.filterMap fun (n, i) =>
    if i.isUnsafe || i.isPartial then none
    else match env.getModuleIdxFor? n with
      | some idx => if (`Loam).isPrefixOf mods[idx.toNat]! then some n else none
      | none => none
  unless names.length == 1138 do throw <| IO.userError s!"unexpected specimen count: {names.length}"
  LeanExport.dumpEnv env (some names)

theorem claim : 1 = 1 := by native_decide

"""Continue after inventory discovered partial runtime helpers (not unsafe proofs)."""
import json, os, signal, subprocess, time
from pathlib import Path
root=Path('/tmp/loam-1963-reaudit')
bin=Path('/tmp/loam-1963-formal/elan/toolchains/leanprover--lean4---v4.35.0/bin')
inv=[json.loads(l) for l in (root/'b-inventory.log').read_text().splitlines() if l.startswith('{')][1:]
names=[r['name'] for r in inv]
assert len(names)==1150 and not any(r['unsafe'] for r in inv)
assert sum(r['partial'] for r in inv)==12
rows=[]
for label,args,outpath in [('selected-export',['env','leanexport','Loam.DurableProofs','--',*names],root/'selected.ndjson'),
                          ('selected-check',['check','--from-export',root/'selected.ndjson','--inadvisably-no-sandbox'],None)]:
    cmd=[str(bin/'lake'),*map(str,args)];start=time.monotonic()
    with (root/(label+'.log')).open('w') as log:
        out=outpath.open('w') if outpath else log
        try:
            p=subprocess.run(['/usr/bin/time','-l',*cmd],cwd=root/'b',
                env=dict(os.environ,PATH=str(bin)+':'+os.environ['PATH']),stdout=out,stderr=log,timeout=600)
        finally:
            if outpath: out.close()
    row=dict(label=label,command=cmd,cwd=str(root/'b'),exit=p.returncode,wall_s=round(time.monotonic()-start,3))
    rows.append(row);(root/'selection-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert p.returncode==0

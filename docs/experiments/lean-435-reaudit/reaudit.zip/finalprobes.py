"""Check the 61 recovered theorem entries with one bundled independent kernel."""
import json, os, subprocess, time
from pathlib import Path
root=Path('/tmp/loam-1963-reaudit')
bins={'a':Path('/Users/user/.elan/toolchains/leanprover--lean4---v4.33.1/bin'),
'b':Path('/tmp/loam-1963-formal/elan/toolchains/leanprover--lean4---v4.35.0/bin')}
rows=[]
def run(label,k,args,stdout=None):
    cmd=[str(bins[k]/args[0]),*map(str,args[1:])];start=time.monotonic()
    with (root/(label+'.log')).open('w') as log:
        p=subprocess.run(['/usr/bin/time','-l',*cmd],cwd=root/k,
            env=dict(os.environ,PATH=str(bins[k])+':'+os.environ['PATH']),stdout=stdout or log,stderr=log,timeout=300)
    row=dict(label=label,command=cmd,cwd=str(root/k),exit=p.returncode,wall_s=round(time.monotonic()-start,3))
    rows.append(row);(root/'final-probe-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert p.returncode==0
inv=[json.loads(l) for l in (root/'b-inventory.log').read_text().splitlines() if l.startswith('{')][1:]
missing=set(json.loads(Path('/tmp/loam-1963-formal/export-coverage.json').read_text())['missing'])
theorems=[r['name'] for r in inv if r['name'] in missing and r['kind']=='thm']
assert len(theorems)==61
export=root/'omitted-theorems.ndjson'
with export.open('w') as out:
    run('omitted-theorems-export','b',['lake','env','leanexport','Loam.DurableProofs','--',*theorems],stdout=out)
run('omitted-theorems-check','b',['lake','check','--from-export',export,'--inadvisably-no-sandbox'])
config=root/'omitted-nanoda.json'
config.write_text(json.dumps(dict(use_stdin=False,export_file_path=str(export),permitted_axioms=['propext','Classical.choice','Quot.sound'],unpermitted_axiom_hard_error=True,num_threads=4,nat_extension=True,string_extension=True),indent=2)+'\n')
run('omitted-theorems-nanoda','b',['nanoda_bin',config])
for k in bins:
    run(k+'-observations','a' if k=='a' else 'b',['lake','build','Loam.Observations'])
    run(k+'-tui-build',k,['lake','build','loamTui'])

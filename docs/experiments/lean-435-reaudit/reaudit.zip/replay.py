"""One-shot re-audit; raw logs and commands, no production configuration changes."""
import json, os, signal, subprocess, time
from pathlib import Path
root = Path('/tmp/loam-1963-reaudit')
bins = {'a': Path('/Users/user/.elan/toolchains/leanprover--lean4---v4.33.1/bin'),
        'b': Path('/tmp/loam-1963-formal/elan/toolchains/leanprover--lean4---v4.35.0/bin')}
rows = []
def run(label, key, args, budget=300, stdout=None, cwd=None):
    cwd = cwd or root/key
    command = [str(bins[key]/'lake'), *map(str, args)]
    env = dict(os.environ, PATH=str(bins[key])+':'+os.environ['PATH'])
    start = time.monotonic()
    with (root/(label+'.log')).open('w') as log:
        p = subprocess.Popen(['/usr/bin/time', '-l', *command], cwd=cwd, env=env,
                             stdout=stdout or log, stderr=log, start_new_session=True)
        try: code = p.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGKILL); p.wait(); code=124
    row = dict(label=label, cwd=str(cwd), command=command, exit=code,
               wall_s=round(time.monotonic()-start, 3), timeout_marker=code==124)
    rows.append(row)
    (root/'results.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    return code
for k in bins:
    assert run(k+'-version', k, ['env','lean','--version']) == 0
    assert run(k+'-product-cold', k, ['build','Loam']) == 0
    assert run(k+'-durable-after-product', k, ['build','Loam.DurableProofs']) == 0
    assert run(k+'-inventory', k, ['env','lean','--run',root/'Inventory.lean']) == 0
# Alternate order for warm runs; no toolchain install or shared build cache in timings.
for rep in range(3):
    for k in (['a','b'] if rep%2==0 else ['b','a']):
        assert run(f'{k}-product-warm-{rep}', k, ['build','Loam']) == 0
        assert run(f'{k}-durable-warm-{rep}', k, ['build','Loam.DurableProofs']) == 0
        assert run(f'{k}-umbrella-check-{rep}', k, ['env','leanchecker','--verbose','Loam.DurableProofs']) == 0
for k in bins:
    inv=[json.loads(l) for l in (root/(k+'-inventory.log')).read_text().splitlines() if l.startswith('{')]
    modules=inv[0]['modules']
    assert len(modules)==22 and all(x.startswith('Loam') for x in modules)
    assert run(k+'-module-check', k, ['env','leanchecker','--verbose',*modules]) == 0
    assert run(k+'-fresh-check', k, ['env','leanchecker','--fresh','--verbose','Loam.DurableProofs'],600) == 0
    for args in [['env','lean','--run','Loam/Tests/PtaMigrationClassifier.lean'],
                 ['env','lean','Loam/Tests/RelationDischargeFrontier.lean'],
                 ['env','lean','--run','Loam/Tests/CurrentCoverageInspection.lean']]:
        assert run(k+'-test-'+Path(args[-1]).stem, k, args)==0
# Explicit official exporter roots: all module-owned constants, not the whole stdlib.
inv=[json.loads(l) for l in (root/'b-inventory.log').read_text().splitlines() if l.startswith('{')][1:]
names=[r['name'] for r in inv]
assert len(names)==1150 and not any(r['unsafe'] for r in inv)
assert sum(r['partial'] for r in inv)==12  # Compiler runtime helpers; Lean replay skips partial definitions.
with (root/'selected.ndjson').open('w') as out:
    assert run('selected-export','b',['env','leanexport','Loam.DurableProofs','--',*names],stdout=out)==0
assert run('selected-check','b',['check','--from-export',root/'selected.ndjson','--inadvisably-no-sandbox'],600)==0

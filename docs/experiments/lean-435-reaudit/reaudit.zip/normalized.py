"""Separate partial runtime helpers from logical proof roots; bounded paranoid replay."""
import json, os, signal, subprocess, time
from pathlib import Path
root=Path('/tmp/loam-1963-reaudit');bin=Path('/tmp/loam-1963-formal/elan/toolchains/leanprover--lean4---v4.35.0/bin');rows=[]
def run(label,args,stdout=None,budget=180):
    cmd=[str(bin/args[0]),*map(str,args[1:])];start=time.monotonic()
    with (root/(label+'.log')).open('w') as log:
        p=subprocess.Popen(['/usr/bin/time','-l',*cmd],cwd=root/'b',env=dict(os.environ,PATH=str(bin)+':'+os.environ['PATH']),stdout=stdout or log,stderr=log,start_new_session=True)
        try: code=p.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL);p.wait();code=124
    row=dict(label=label,command=cmd,cwd=str(root/'b'),exit=code,wall_s=round(time.monotonic()-start,3))
    rows.append(row);(root/'normalized-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert code in [0,124] if 'paranoid' in label else code==0
with (root/'normalized.ndjson').open('w') as out:
    run('normalized-export',['lake','env','lean','--run',root/'SelectedExport.lean'],stdout=out)
for i in range(3):
    run(f'normalized-leanchecker-{i}',['lake','env','leanchecker','--silent','--from-export',root/'normalized.ndjson'])
run('normalized-paranoid',['lake','check','--from-export',root/'normalized.ndjson','--paranoid','--inadvisably-no-sandbox'])
# Independent membership check, including private theorem entries; not a proof verdict.
names={0:''};exported=set();partial=[]
with (root/'normalized.ndjson').open() as f:
    for line in f:
        item=json.loads(line)
        if 'in' in item:
            v=item.get('str',item.get('num'));piece=v['str'] if 'str' in v else str(v['i']);prefix=names[v['pre']];names[item['in']]=prefix+'.'+piece if prefix else piece
        for k in ['axiom','def','thm','opaque','quot']:
            if k in item:
                exported.add(names[item[k]['name']])
                if item[k].get('safety')=='partial':partial.append(names[item[k]['name']])
        if 'inductive' in item:
            for k in ['types','ctors','recs']:
                for v in item['inductive'][k]:exported.add(names[v['name']])
inv=[json.loads(l) for l in (root/'b-inventory.log').read_text().splitlines() if l.startswith('{')][1:]
expected={r['name'] for r in inv if not r['partial'] and not r['unsafe']};theorems={r['name'] for r in inv if r['kind']=='thm'}
assert expected<=exported and theorems<=exported and not partial
report=dict(expected_candidates=len(expected),present_candidates=len(expected & exported),theorems=len(theorems),partial_exports=partial,total_exported=len(exported),bytes=(root/'normalized.ndjson').stat().st_size)
(root/'normalized-inventory.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)

axiom bad : False
theorem claim : False := bad

"""Same normalized artifact via a roots-only adapter and the compiled official exporter."""
import hashlib, json, os, subprocess, time
from pathlib import Path
root=Path('/tmp/loam-1963-reaudit');bin=Path('/tmp/loam-1963-formal/elan/toolchains/leanprover--lean4---v4.35.0/bin');rows=[]
def run(label,args,path):
    cmd=[str(bin/'lake'),*map(str,args)];start=time.monotonic()
    with (root/(label+'.log')).open('w') as log, path.open('w') as out:
        p=subprocess.run(['/usr/bin/time','-l',*cmd],cwd=root/'b',env=dict(os.environ,PATH=str(bin)+':'+os.environ['PATH']),stdout=out,stderr=log,timeout=180)
    row=dict(label=label,command=cmd,cwd=str(root/'b'),exit=p.returncode,wall_s=round(time.monotonic()-start,3))
    rows.append(row);(root/'roots-cli-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert p.returncode==0
run('roots-only',['env','lean','--run',root/'SelectedRoots.lean'],root/'roots.txt')
names=(root/'roots.txt').read_text().splitlines();assert len(names)==1138 and len(set(names))==1138
run('roots-cli-export',['env','leanexport','Loam.DurableProofs','--',*names],root/'roots-cli.ndjson')
a=hashlib.sha256((root/'normalized.ndjson').read_bytes()).hexdigest();b=hashlib.sha256((root/'roots-cli.ndjson').read_bytes()).hexdigest();assert a==b
(root/'roots-cli-equivalence.json').write_text(json.dumps(dict(byte_identical=True,sha256=a,candidates=len(names)),indent=2)+'\n')

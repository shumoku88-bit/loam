"""Inventory NDJSON declarations; membership is not a kernel verdict."""
import collections, hashlib, json
from pathlib import Path
root=Path('/tmp/loam-1963-reaudit')
inv=[json.loads(l) for l in (root/'b-inventory.log').read_text().splitlines() if l.startswith('{')][1:]
expected={x['name'] for x in inv}
names={0:''}; declarations=set(); kinds=collections.Counter()
path=root/'selected.ndjson'
with path.open() as f:
    for line in f:
        item=json.loads(line)
        if 'in' in item:
            value=item.get('str',item.get('num'))
            piece=value['str'] if 'str' in value else str(value['i'])
            prefix=names[value['pre']]
            names[item['in']]=prefix+'.'+piece if prefix else piece
        for k in ['axiom','def','thm','opaque','quot']:
            if k in item:
                declarations.add(names[item[k]['name']]);kinds[k]+=1
        if 'inductive' in item:
            for k in ['types','ctors','recs']:
                for v in item['inductive'][k]:
                    declarations.add(names[v['name']]);kinds[k]+=1
assert expected <= declarations
missing=set(json.loads(Path('/tmp/loam-1963-formal/export-coverage.json').read_text())['missing'])
assert missing <= declarations and len(missing)==153
r=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
       exported_declarations=len(declarations),kind_counts=dict(kinds),loam_candidates=len(expected),
       present_candidates=len(expected & declarations),recovered_omissions=len(missing),
       partial_candidates=sum(x['partial'] for x in inv),theorem_candidates=sum(x['kind']=='thm' for x in inv))
(root/'selected-export-inventory.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

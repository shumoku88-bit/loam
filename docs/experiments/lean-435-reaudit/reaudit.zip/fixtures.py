"""One-shot positive/negative fixture and selected paranoid replay."""
import json, os, shutil, signal, subprocess, time
from pathlib import Path
root=Path('/tmp/loam-1963-reaudit')
bin=Path('/tmp/loam-1963-formal/elan/toolchains/leanprover--lean4---v4.35.0/bin')
rows=[]
def run(label,cwd,args,expected,budget=180):
    cmd=[str(bin/'lake'),*map(str,args)]; start=time.monotonic()
    with (root/(label+'.log')).open('w') as log:
        p=subprocess.Popen(['/usr/bin/time','-l',*cmd],cwd=cwd,
            env=dict(os.environ,PATH=str(bin)+':'+os.environ['PATH']),
            stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try: code=p.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL);p.wait();code=124
    row=dict(label=label,command=cmd,cwd=str(cwd),exit=code,expected=expected,
             wall_s=round(time.monotonic()-start,3))
    rows.append(row);(root/'fixture-results.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True);assert code in expected,row
for n,expected in [(165,[0]),(166,[1]),(167,[1]),(168,[0]),(238,[0])]:
    d=root/f'fixture{n}';d.mkdir()
    for f in ['Challenge.lean','Solution.lean','config.json']:
        shutil.copyfile(root/'docs'/'verification'/f'observation{n}'/f,d/f)
    (d/'lakefile.toml').write_text(f'name = "fixture{n}"\n[[lean_lib]]\nname = "Challenge"\n[[lean_lib]]\nname = "Solution"\n')
    run(f'fixture{n}-build',d,['build','Challenge','Solution'],[0])
    run(f'fixture{n}-normal',d,['comparator','--config','config.json','--inadvisably-no-sandbox'],expected)
    if n in [165,168]:
        run(f'fixture{n}-paranoid',d,['comparator','--config','config.json','--paranoid','--inadvisably-no-sandbox'],[1] if n==165 else [0])
run('selected-paranoid',root/'b',['check','--from-export',root/'selected.ndjson','--paranoid','--inadvisably-no-sandbox'],[0,1,124])
for module,target,expected in [('Dormant','unused_fact',[0]),('Used','claim',[1]),('Native','claim',[1])]:
    cwd=root/(module+'-b'); export=root/(module+'-selected.ndjson')
    cmd=[str(bin/'lake'),'env','leanexport',module,'--',target]
    with export.open('w') as out:
        p=subprocess.run(cmd,cwd=cwd,env=dict(os.environ,PATH=str(bin)+':'+os.environ['PATH']),stdout=out,stderr=subprocess.PIPE,text=True)
    assert p.returncode==0,p.stderr
    run(module+'-official',cwd,['check','--from-export',export,'--inadvisably-no-sandbox'],expected)
    if module=='Dormant':
        run(module+'-official-paranoid',cwd,['check','--from-export',export,'--paranoid','--inadvisably-no-sandbox'],[1])

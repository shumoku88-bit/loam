"""Static evidence table for the original 153 omissions; counts are asserted."""
import collections, json
from pathlib import Path
root=Path('/tmp/loam-1963-reaudit')
rows=[json.loads(l) for l in (root/'b-inventory.log').read_text().splitlines() if l.startswith('{')][1:]
missing=set(json.loads(Path('/tmp/loam-1963-formal/export-coverage.json').read_text())['missing'])
assert len(missing)==153
counts=collections.Counter()
lines=['name\tmodule\tkind\tcategory\tinternal\tunsafe\tpartial\tomission_cause']
for r in sorted(rows,key=lambda r:r['name']):
    if r['name'] not in missing: continue
    n=r['name']
    if r['kind']=='thm':
        if n.endswith('admitAll?_isSome_eq_currentUnitsAdmissible') or n.endswith('buildCoverageIndex_getD_eq_currentCoverageFor'):
            category='source-written private theorem'
        elif any(s in n for s in ['.mk.inj','.mk.sizeOf_spec','.mk.congr_simp']):
            category='generated structure theorem'
        elif '.eq_' in n or n.endswith('.eq_def') or n.endswith('.else_eq'):
            category='generated equation theorem'
        elif '._simp_' in n or n.endswith('.congr_simp'):
            category='generated simplification theorem'
        else: raise AssertionError(n)
    else:
        assert r['kind']=='def'
        if r['partial']: category='partial compiler runtime helper'
        elif n.endswith('.currentUnitsAdmissible'): category='source-written private definition'
        else: category='generated safe definition'
    assert r['internal'] and not r['unsafe']
    counts[category]+=1
    lines.append('\t'.join([n,r['module'],r['kind'],category,str(r['internal']),str(r['unsafe']),str(r['partial']),'internal non-root, not reached from default public roots']))
assert dict(counts)=={'generated safe definition':79,'partial compiler runtime helper':12,'generated simplification theorem':3,'generated equation theorem':43,'generated structure theorem':13,'source-written private theorem':2,'source-written private definition':1}
(root/'omissions.tsv').write_text('\n'.join(lines)+'\n')
print(json.dumps(counts,indent=2))
